Hi guys 
I have built several classifiers with different techniques. please let each of us run one before
sleeping it takes quite a lot of time to complete.

-Adriano please run the Vote3Classifiers this should be heaviest 
-Guimel please run the BoostingIBK5Folds
-Her Patrick run the Bagging_IBK_5_folds bitte
(two of them are actually running on my computer)



 to run proceed as folows :
- Lunch weka
- Select the knowledge flow option in the welcoming gui
- in the knowledge flow window menu do file->open and open your corresponding flow chart file
- load the training and the testing data by clicking on the corresponding arff loader and selecting the
the files using the browse button
- double click on the last element in the chain named "textSaver" to set the file where the results will be stored
- press on the play button at the top left of the window
- wait for fiew seconds to be sure that the files loaded without any error
- You can now go to bed :)
